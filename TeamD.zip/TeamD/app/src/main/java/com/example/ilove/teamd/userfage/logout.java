package com.example.ilove.teamd.userfage;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.ilove.teamd.R;

public class logout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logout);
    }
}
